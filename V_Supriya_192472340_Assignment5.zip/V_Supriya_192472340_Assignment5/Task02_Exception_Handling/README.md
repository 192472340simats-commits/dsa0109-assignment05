# Task 02 – Exception Handling
Compile: `g++ -std=c++17 -Wall -Wextra -O2 complete_code.cpp -o exceptions`
Run: `./exceptions`
Shows validation exceptions, custom claim exceptions, logging and `throw;` rethrowing, and RAII destruction.
