# Task 03 – Performance Comparison
Compile with optimization: `g++ -std=c++17 -Wall -Wextra -O2 benchmark.cpp -o benchmark`
Run: `./benchmark`
The program measures virtual dispatch versus a tagged structure/switch for 1,000, 1,000,000 and 10,000,000 bills. Timings depend on hardware and compiler; record your own run.
