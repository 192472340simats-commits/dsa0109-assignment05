#include <iostream>
#include <vector>
#include <chrono>
#include <cstdint>
struct VirtualBill { virtual ~VirtualBill()=default; virtual double total() const=0; };
struct OP final : VirtualBill { double a,b; OP(double x,double y):a(x),b(y){} double total() const override{return a+b;} };
struct IP final : VirtualBill { double a,b; IP(double x,double y):a(x),b(y){} double total() const override{return a*b;} };
struct TaggedBill { int type; double a,b; };
volatile double sink=0;
template<class F> long long measure(F f) {
 auto s=std::chrono::steady_clock::now(); sink=f();
 return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-s).count();
}
int main() {
 for (int n : {1000,1000000,10000000}) {
  std::vector<VirtualBill*> v; v.reserve(n);
  std::vector<TaggedBill> t; t.reserve(n);
  for(int i=0;i<n;++i) {
   if(i%2==0){v.push_back(new OP(500,1200));t.push_back({0,500,1200});}
   else {v.push_back(new IP(3,2500));t.push_back({1,3,2500});}
  }
  auto tv=measure([&](){double x=0;for(auto p:v)x+=p->total();return x;});
  auto ts=measure([&](){double x=0;for(auto b:t)x+=(b.type==0?b.a+b.b:b.a*b.b);return x;});
  std::cout<<"Bills: "<<n<<" | virtual: "<<tv<<" us | switch: "<<ts<<" us | total: "<<sink<<'\n';
  for(auto p:v) delete p;
 }
}
