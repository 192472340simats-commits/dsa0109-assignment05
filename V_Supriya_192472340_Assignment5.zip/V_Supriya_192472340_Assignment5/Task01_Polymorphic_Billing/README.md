# Task 01 – Polymorphic Billing
Compile: `g++ -std=c++17 -Wall -Wextra -O2 complete_code.cpp -o billing`
Run: `./billing` (Windows: `billing.exe`)
Demonstrates four derived bill types, a virtual base interface, virtual destruction, and three payer policies.
