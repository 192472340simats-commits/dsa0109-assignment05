#include <iostream>
#include <string>
#include <vector>
#include <memory>

class Bill {
protected:
    std::string patient;
public:
    explicit Bill(const std::string& p) : patient(p) {}
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const { return "Bill"; }
    void print() const { std::cout << type() << ' ' << patient << ": " << total() << '\n'; }
};
class OutPatient : public Bill {
    double consultation, tests;
public:
    OutPatient(const std::string& p, double c, double t)
        : Bill(p), consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};
class InPatient : public Bill {
    int days; double perDay, surgery;
public:
    InPatient(const std::string& p, int d, double rate, double s)
        : Bill(p), days(d), perDay(rate), surgery(s) {}
    double total() const override { return days * perDay + surgery; }
    std::string type() const override { return "IP"; }
};
class DayCareBill : public Bill {
    double packagePrice;
public:
    DayCareBill(const std::string& p, double price) : Bill(p), packagePrice(price) {}
    double total() const override { return packagePrice; }
    std::string type() const override { return "DayCare"; }
};
class EmergencyBill : public Bill {
    double base, hourly; int hours;
public:
    EmergencyBill(const std::string& p, double b, double h, int hrs)
        : Bill(p), base(b), hourly(h), hours(hrs) {}
    double total() const override { return base + hourly * hours; }
    std::string type() const override { return "Emergency"; }
};
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& b) const = 0;
    virtual std::string name() const = 0;
};
class SelfPay : public Payer {
public:
    double amountCovered(const Bill& b) const override { return b.total(); }
    std::string name() const override { return "SelfPay"; }
};
class Insurance : public Payer {
    double limit, copayPercent;
public:
    Insurance(double l, double c) : limit(l), copayPercent(c) {}
    double amountCovered(const Bill& b) const override {
        return std::min(limit, b.total() * (1.0 - copayPercent / 100.0));
    }
    std::string name() const override { return "Insurance"; }
};
class GovernmentScheme : public Payer {
    double packageRate;
public:
    explicit GovernmentScheme(double rate) : packageRate(rate) {}
    double amountCovered(const Bill& b) const override { return std::min(packageRate, b.total()); }
    std::string name() const override { return "GovernmentScheme"; }
};
int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatient>("Ravi", 500, 1200));
    bills.push_back(std::make_unique<InPatient>("Meena", 3, 2500, 40000));
    bills.push_back(std::make_unique<DayCareBill>("Arun", 18000));
    bills.push_back(std::make_unique<EmergencyBill>("Sara", 5000, 1500, 2));
    double grandTotal = 0;
    for (const auto& b : bills) { b->print(); grandTotal += b->total(); }
    std::cout << "Daily total: " << grandTotal << '\n';
    SelfPay self;
    Insurance insurance(30000, 20);
    GovernmentScheme scheme(15000);
    for (const auto& b : bills) {
        std::cout << b->type() << " | " << self.name() << ": " << self.amountCovered(*b)
                  << " | " << insurance.name() << ": " << insurance.amountCovered(*b)
                  << " | " << scheme.name() << ": " << scheme.amountCovered(*b) << '\n';
    }
}
