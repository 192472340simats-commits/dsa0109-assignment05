# ASSIGNMENT 5 – CO5
## Reliable Software with Runtime Polymorphism and Exceptions

**Student Name:** V. Supriya  
**Register Number:** 192472340  
**Course Outcome:** CO5  
**Submission:** Individual Assignment 5

## Folder contents
- `Assignment_5_Source.pdf` – supplied assignment instructions.
- `PartA_Design/Design_Answers.md` – design explanations, UML text sketch, pseudocode, vtable and exception strategy.
- `Task01_Polymorphic_Billing/` – completed TODO 1–3 program, four bill types, payer interface, actual output.
- `Task02_Exception_Handling/` – claim validation, custom exception, catch/rethrow, RAII test, actual output.
- `Task03_Performance_Comparison/` – optimized virtual-dispatch versus tagged-switch benchmark and measured output.
- `Task04_Extension_and_Sanitizer/` – added bill type and payer, exception/resource-safety example and sanitizer status.
- `Screenshots/` – PNG captures of the actual program output for each task.

## Compiler and commands
Compiler: GNU g++ (C++17). The source programs use standard C++17.

```bash
g++ -std=c++17 -Wall -Wextra -O2 complete_code.cpp -o program
./program
```

For the benchmark, retain `-O2`. For the sanitizer test:
```bash
g++ -std=c++17 -Wall -Wextra -fsanitize=address -g extension.cpp -o extension
./extension
```

## Important submission checklist
1. Open every `.cpp` file and run it on your own system.
2. Re-capture screenshots from your own terminal/IDE if your faculty requires direct student execution evidence.
3. Complete the experimental investigations requested in the PDF (including removed-virtual tests, invalid-rate tests, 0%/1%/50% exception-vs-return-code timings, and the full sanitizer report).
4. Create the required GitHub repository named `DSA01-192472340-Assignment5`, commit each task progressively, and add the faculty as collaborator or make it public.
5. Add your actual GitHub repository URL to the cover page/report and submit it. No GitHub URL has been invented or supplied in this folder.

**Note:** Benchmark timings vary by computer, compiler version, and system load. The included timings are from the execution environment used to prepare this folder; rerun them on your machine for your own experimental record.
