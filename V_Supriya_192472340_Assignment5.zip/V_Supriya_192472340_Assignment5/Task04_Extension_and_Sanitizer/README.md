# Task 04 – Extension and Resource Safety
Compile: `g++ -std=c++17 -Wall -Wextra -fsanitize=address -g extension.cpp -o extension`
Run: `./extension`
Adds `TelemedicineBill` and `CorporatePayer` without editing existing class implementations. Uses `unique_ptr` for automatic cleanup. Run locally with AddressSanitizer to capture the sanitizer report.
