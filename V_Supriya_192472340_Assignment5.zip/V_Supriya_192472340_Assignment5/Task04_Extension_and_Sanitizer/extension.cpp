#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
class Bill { public: virtual ~Bill()=default; virtual double total()const=0; virtual std::string type()const=0; };
class OPBill:public Bill { double c,t; public: OPBill(double x,double y):c(x),t(y){} double total()const override{return c+t;} std::string type()const override{return "OP";} };
class TelemedicineBill:public Bill { double consultation, platformFee; public: TelemedicineBill(double c,double f):consultation(c),platformFee(f){} double total()const override{return consultation+platformFee;} std::string type()const override{return "Telemedicine";} };
class Payer { public: virtual ~Payer()=default; virtual double cover(const Bill&)const=0; };
class SelfPay:public Payer { public: double cover(const Bill& b)const override{return b.total();} };
class CorporatePayer:public Payer { double percent; public: explicit CorporatePayer(double p):percent(p){} double cover(const Bill& b)const override{return b.total()*percent/100.0;} };
int main() {
 try {
  std::vector<std::unique_ptr<Bill>> bills;
  bills.push_back(std::make_unique<OPBill>(500,1200));
  bills.push_back(std::make_unique<TelemedicineBill>(800,100));
  SelfPay self; CorporatePayer corporate(75);
  for(const auto& b:bills) std::cout<<b->type()<<" total="<<b->total()<<" self="<<self.cover(*b)<<" corporate="<<corporate.cover(*b)<<'\n';
  throw std::runtime_error("simulated claim failure");
 } catch(const std::exception& e) { std::cout<<"caught: "<<e.what()<<'\n'; }
}
