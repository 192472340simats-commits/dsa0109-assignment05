# PART A – DESIGN (CO5)
**Student:** V. Supriya  
**Register Number:** 192472340  
**Assignment:** Assignment 5 – Reliable Software with Runtime Polymorphism and Exceptions

## A1. Polymorphic bill hierarchy
Common data: patient identifier/name. Common operations: `total()`, `type()`, and `print()`.
`Bill` is abstract. `total()` is pure virtual; `type()` is virtual; the destructor is virtual. Derived classes override the virtual operations:
- `OutPatientBill`: consultation + tests.
- `InPatientBill`: days × daily room rate + procedures + medicines.
- `DayCareBill`: package price.
- `EmergencyBill`: base charge + time-based charge.

### UML (text form)
```text
                 <<abstract>> Bill
       ---------------------------------------
       - patient : string
       + total() : double {pure virtual}
       + type() : string {virtual}
       + print() : void
       + ~Bill() {virtual}
           /       |          |          \
          /        |          |           \
 OutPatientBill InPatientBill DayCareBill EmergencyBill
   total()        total()       total()     total()
   type()         type()        type()      type()
```
Pseudocode:
```text
ALGORITHM DailyTotal(bills[0..n-1])
    total ← 0
    FOR each bill IN bills
        total ← total + bill.total()
    END FOR
    RETURN total
END ALGORITHM
```
Alternative: a single record with a type tag and switch in `total()`. Both scan n bills in O(n). The tagged record may use less per-object dispatch overhead, but adding a type requires editing the switch and central code. The virtual hierarchy localizes each new type in a new derived class.

## A2. Runtime binding
A non-virtual call is resolved from the static type at compile time. A virtual call through `Bill*` is dispatched at run time to the object's override. The object's vptr selects the class vtable; its `total` slot points to the correct derived implementation. `Bill` needs a virtual destructor so `delete basePointer` invokes the derived destructor before the base destructor.
Example vtable sketch:
```text
Bill vtable:          OutPatientBill vtable:      InPatientBill vtable:
~Bill                  ~OutPatientBill             ~InPatientBill
total (pure virtual)   total -> OP total           total -> IP total
type -> Bill           type -> "OP"                type -> "IP"
```
In the sample `show()` is non-virtual, but its call to virtual `total()` is dynamically dispatched. Expected output: `500 ~OPBill ~Bill`.

## A3. Payer interface
`Payer` is abstract with `amountCovered(const Bill&)`. `SelfPay` covers the full bill. `Insurance` applies a policy cover limit and co-payment percentage. `GovernmentScheme` uses configured package rates. A corporate payer can be added as another derived class without changing existing payer classes.
Alternative: function pointers or `std::function` store a callable policy. Call cost is O(1) for either design; an abstract object naturally keeps policy data (limit, percentage) beside the behavior, while a callable may capture that data.

## A4. Exception strategy
Possible errors: negative charges, claim above cover, unknown package, missing patient record, invalid numeric input, and allocation failure. Suggested hierarchy:
```text
std::exception
  └── std::runtime_error
       └── BillingError
            ├── ClaimError
            ├── InvalidChargeError
            ├── UnknownPackageError
            └── MissingPatientError
```
Validation, parsing and claim approval may throw. Destructors and cleanup operations should be `noexcept`; destructors must not throw during stack unwinding because a second exception can terminate the program. Return codes are an alternative: they make errors explicit but require checking and propagating status at each call. Normal-path cost is small; error-path handling is explicit.

## A5. Recovery and rethrowing
Catch an exception at the layer that can add context or recover. Log at a service boundary and use `throw;` to preserve the original exception type. Catch at the application boundary to report a clear message. Stack unwinding destroys automatic objects in reverse construction order. RAII wrappers (`std::string`, `std::vector`, `std::unique_ptr`, file streams) release resources automatically.
For the Guard example, expected output: `~f ~main caught 42`. The `not printed` statement is skipped because control transfers immediately to the matching handler.
